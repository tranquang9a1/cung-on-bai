CREATE DATABASE  IF NOT EXISTS `cungonbai_data` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `cungonbai_data`;
-- MySQL dump 10.13  Distrib 5.6.19, for osx10.7 (i386)
--
-- Host: 128.199.209.247    Database: cungonbai_data
-- ------------------------------------------------------
-- Server version	5.5.35-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_message`
--

DROP TABLE IF EXISTS `tbl_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) DEFAULT NULL,
  `fromUsername` varchar(45) DEFAULT NULL,
  `created_date` int(11) DEFAULT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_message`
--

LOCK TABLES `tbl_message` WRITE;
/*!40000 ALTER TABLE `tbl_message` DISABLE KEYS */;
INSERT INTO `tbl_message` VALUES (1,'asd','qwe',123),(2,'haha','trungdqse60994',1413985402),(3,'hehe','trungdqse60994',1413985411),(4,'asdasd','trungdqse60994',1413987984),(5,'ueiuqhwe','trungdqse60994',1413987987),(6,'hehe','trungdqse60994',1413988038),(7,'hah','trungdqse60994',1413988064),(8,'hohoo','trungdqse60994',1413988068),(9,'oooo','trungdqse60994',1413988072),(10,'ojiuiuh','trungdqse60994',1413988077),(11,'hehe99999','trungdqse60994',1413988104),(12,'juhuhu','trungdqse60994',1413988110),(13,'kok','trungdqse60994',1413989010),(14,'asd','trungdqse60994',1413989480),(15,'123123','trungdqse60994',1413989530),(16,'lklkj','trungdqse60994',1413989555),(17,'rwerwer','trungdqse60994',1413989565),(18,'asdasd','trungdqse60994',1413989647),(19,'qweqwe','trungdqse60994',1413989649),(20,'ertert','trungdqse60994',1413989656),(21,'pok','trungdqse60994',1413989980),(22,'jklj','trungdqse60994',1413990025),(23,'poi','trungdqse60994',1413990095),(24,'ok','trungdqse60994',1413990133),(25,'poi','trungdqse60994',1413990192),(26,'098','trungdqse60994',1413990231),(27,'kkoko','trungdqse60994',1413990290),(28,'asdasd','trungdqse60994',1413990311),(29,'sdfssd','trungdqse60994',1413990333),(30,'zxc','trungdqse60994',1413990339),(31,'123','trungdqse60994',1413990344),(32,'k','trungdqse60994',1413990543),(33,'how are you?','trungdqse60994',1413990550);
/*!40000 ALTER TABLE `tbl_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-22 22:10:11
